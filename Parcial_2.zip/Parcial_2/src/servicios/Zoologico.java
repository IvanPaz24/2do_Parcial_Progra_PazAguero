package servicios;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import modelo.Animal;
import modelo.TipoAlimentacion;

public class Zoologico <T> {
    
    List<T> items = new ArrayList<>();
    
    public void agregar(T a){
        // verificaciones que no pasen datos errones
        if (a == null) {
            throw new NullPointerException();
        }
            
        //si el dato es coorecto se agrega a la lista
        if (a instanceof CSVSerializable) {
            items.add(a);   
        }
    }
    
    public T obtenerAnimal(int indice) {
        validarIndice(indice);
        return items.get(indice);
    }
    
    public void eliminarAnimal(int indice) {
        validarIndice(indice);
        items.remove(indice);
    }
    
    private void validarIndice(int indice){
        if (indice < 0 || indice >= items.size()) {
            throw new IndexOutOfBoundsException("Indice invalido");
        }
    }
    
    public List <T> filtrar(Predicate<? super T> criterio) {
        List<T> aux = new ArrayList<>();
        
        for (T item : items) {
            //segun el filtro que se ingrese por parametro las va separando
            if (criterio.test(item)) {
                aux.add(item);
            }
        }
        
        return aux;
    }
          
    
    
    public List<T> ordenar(){
        
        List <T> aux = new ArrayList<>(items);
                
        aux.sort(null);
        
        return aux;
        
    }
    
    public List<T> ordenar(Comparator<? super T> comparador) {
        
        List<T> aux = new ArrayList<>(items);
        
        aux.sort(comparador);
        
        return aux;
    }
     
     

    public <T> void guardarEnArchivo(String path){
        //archivo binario
        try(FileOutputStream archivo = new FileOutputStream(path);
                ObjectOutputStream salida = new ObjectOutputStream(archivo)){
            //tranformo a objeto
            salida.writeObject(items);
            
        }catch(IOException ex){
            //imprime la pila de llamadas 
            ex.printStackTrace();
        }
       
    }
    
    public List<T> cargarDesdeArchivo(String path){
        //cargar archivo binario
        List<T> toReturn = new ArrayList<>();
        
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))){
            //tranformo los datos y los paso a la lista
            toReturn = (List<T>) input.readObject();
            
        } catch (IOException | ClassNotFoundException ex) {
            //si en el catch hago lo mismo puedo juntarlas, multicatch
            ex.printStackTrace();
        }
        
        return toReturn;
    }
            
    
    public void guardarEnCSV(String path){
        File archivo = new File(path);
        
        try {
            if (archivo.exists()) {
                System.out.println("El archivo ya existe");        
            }
            else{
                archivo.createNewFile();
            }

        } catch (IOException ex) {
            
            System.out.println("Ocurrio un error al crear el archivo");
            
        }
        
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            //System.out.println("dni,nombre,sueldo,sector\n");
            bw.write("id,nombre,especie,tipo\n");//encabezado
            for (T e : items){
                if (e instanceof Animal a) {
                    
                    bw.write(a.toCSV() + "\n");
                }
                
            }
            
            
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
    
    public List<Animal> cargarDesdeCSV(String path){
     List<Animal> toReturn = new ArrayList<>();

     try ( BufferedReader bf = new BufferedReader(new FileReader(path))){

         String linea;
         //la primer linea es la del encabezado, salteo lectura fantasma
         bf.readLine();

         while((linea = bf.readLine()) != null){
             if (linea.endsWith("\n")) {
                 //corta el ultimo caracter \n(salto de linea)
                 linea.substring(linea.length()-1);
             }
             //devuelve un array mediante las comas que lo separan
             //arrayString
             String[] data = linea.split(",");
             //data igual a 4 elementos porque los animales tiene 4 datos
             if (data.length == 4) {

                //parseo del csv a 
                int id = Integer.parseInt(data[0]);
                String nombre = data[1];
                String especie = data[2];
                 TipoAlimentacion tipo = TipoAlimentacion.valueOf(data[3]);
                //creo el animal con los datos extraidos
                Animal a = new Animal(id, nombre, especie, tipo);
                //lo agredo a la lista
                toReturn.add(a);
             }
         }

           
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        } 
        
        return toReturn;
                
    }
    
    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T item : items) {
            //metodo de la interfaz funcional consumer, lo que pase por parametro es lo que hace con items
            accion.accept(item);
        }
    }
    
    
}
