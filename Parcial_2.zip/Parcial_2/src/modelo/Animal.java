package modelo;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.List;
import servicios.CSVSerializable;


public class Animal implements Comparable<Animal>, Serializable, CSVSerializable{
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion tipo;

    public Animal(int id, String nombre, String especie, TipoAlimentacion tipo) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoAlimentacion getTipo() {
        return tipo;
    }
    
    

    @Override
    public int compareTo(Animal o) {
        return Integer.compare(o.id, id);
    }
    
    @Override
    public String toString() {
        return "Animal{" + "id=" + id + ", nombre=" + nombre + ", especie=" + especie + ", tipo=" + tipo + '}';
    }
    
    @Override
    public String toCSV(){
        return getId() + "," + nombre + "," + especie + "," + tipo.toString();
    }

      
    
}
